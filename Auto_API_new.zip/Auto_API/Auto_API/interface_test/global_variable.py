
from .models import testcase_module

def settings(request):
    if not request.user.has_perm('projects.modify_information'):
        content = {
           "modify":0,
           "edit":0
        }
    else:
        content = {
            "modify":1,
            "edit":1
        }
    return content