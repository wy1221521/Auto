from django.http import JsonResponse
from django.shortcuts import render
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout

#登录功能前后端交互
class Login(APIView):
    message=[]
    def post(self,request):
        username= request.POST['username']
        password= request.POST['password']
        user=authenticate(username=username, password=password)
        if user is not None:
            if user.is_active:
                 login(request,user)
                 request.session['IS_LOGIN'] = True     #设置session，django中session已写好，会自动存入cookie
                 self.message.append({
                    "code": 0,
                    "error": True,
                    "msg": 'success'
                })
            else:
                self.message.append({
                    "code": 1,
                    "error": True,
                    "msg": 'Invalid account or password'
                })

        else:
            self.message.append({
                "code": 1,
                "error": True,
                "msg": 'Empty account or password'
            })
        return JsonResponse(self.message, safe=False)