import time
import requests
import random
import datetime
import json
import os, re, robot
from Auto_API.settings import lock
from django.http import JsonResponse
from django.http import HttpResponse
from django.shortcuts import render
from rest_framework.views import APIView
from .models import Suites, TestsuiteResults, TestcaseResults, InterfaceCases, Services


# from django.contrib.auth import authenticate, login


# Create your views here.


# show doc

def Index(request):
    return render(request, "interface_test/test.html")


# 获取套件列表
class GetSuiteView(APIView):
    """
           @api {GET} /SuiteList?service_id=XXX/ 获取套件列表
           @apiVersion 1.0.0
           @apiDescription 获取套件列表, 若service_id 未指定则获取全部套件
           @apiName GetSuiteView
           @apiGroup InterfaceTest
           @apiParam {string} service_id 套件ID
           @apiSuccessExample  请求成功
           HTTP/1.1 200 OK
           {
               "data": [{"suite_id": "TS_INT_3", "suite_name": "\u65e5\u671f", "suite_creator": "me", "suite_createtime": "20180516", "suite_comments": "eqwewqe", "suite_status": "3"}, {"suite_id": "TS_INT_4", "suite_name": "\u5929\u6c14", "suite_creator": "", "suite_createtime": "2018/05/29 17:43:14", "suite_comments": "", "suite_status": "1"}],
               "code": 0,
               "error": false,
               "msg": u'success'
           }

           @apiSuccess {Array} data  数据列表
           @apiSuccess {Number} code 0:成功；1：失败
           @apiSuccess {Boolean} error false
           @apiSuccess {String} message 返回消息
    """
    message = {}

    def get(self, request):
        data = []
        if request.method == 'GET':
            Sid = request.GET.get('service_id')
            if Sid:
                for o in Suites.objects.filter(service_id=Sid).order_by('id'):
                    suite_id = o.suite_id
                    suite_name = o.suite_name
                    suite_description = o.suite_description
                    # services_id = o.services_id
                    # project_id = o.project_id
                    status = o.status
                    # robotfile = o.robotfile
                    suite_creator = o.suite_creator
                    suite_createtime = o.suite_createtime
                    data.append({
                        'suite_id': suite_id,
                        'suite_name': suite_name,
                        'suite_creator': suite_creator,
                        'suite_createtime': suite_createtime,
                        'suite_comments': suite_description,
                        'suite_status': status,
                    })
                self.message['data'] = data
                if self.message:
                    self.message["code"] = 0
                    self.message["error"] = False
                    self.message["msg"] = 'success'
                else:
                    self.message = {
                        "code": 1,
                        "error": True,
                        "msg": 'method not allowed'
                    }
                return JsonResponse(self.message, safe=False)
            else:
                for o in Suites.objects.all().order_by('id'):
                    # id = o.id
                    suite_id = o.suite_id
                    suite_name = o.suite_name
                    suite_description = o.suite_description
                    # services_id = o.services_id
                    # project_id = o.project_id
                    status = o.status
                    # robotfile = o.robotfile
                    suite_creator = o.suite_creator
                    suite_createtime = o.suite_createtime
                    data.append({
                        'suite_id': suite_id,
                        'suite_name': suite_name,
                        'suite_creator': suite_creator,
                        'suite_createtime': suite_createtime,
                        'suite_comments': suite_description,
                        'suite_status': status,
                    })
                self.message['data'] = data
                if self.message:
                    self.message["code"] = 0
                    self.message["error"] = False
                    self.message["msg"] = 'success'
                else:
                    self.message = {
                        "code": 1,
                        "error": True,
                        "msg": 'method not allowed'
                    }
                return JsonResponse(self.message, safe=False)
        else:
            self.message["code"] = 1
            self.message["error"] = True
            self.message["msg"] = 'method not allowed'
            return JsonResponse(self.message, safe=False)


# 获取套件信息
class GetSuiteMsg(APIView):
    """
              @api {GET} /SuiteMsg?suite_id=XXX/ 获取套件信息
              @apiVersion 1.0.0
              @apiDescription 获取套件信息
              @apiName GetSuiteMsg
              @apiGroup InterfaceTest
              @apiParam {Number} suite_id 套件ID
              @apiSuccessExample  请求成功
              HTTP/1.1 200 OK
              {
                  "suite_name": "\u65e5\u671f",
                  "suite_status": "3",
                  "suite_comments": "eqwewqe",
                  "code": 0,
                  "error": false,
                  "msg": u'success'
              }
              @apiSuccess {String} suite_name  套件名
              @apiSuccess {String} suite_status  套件状态
              @apiSuccess {String} suite_comments  套件说明
              @apiSuccess {Number} code 0
              @apiSuccess {Boolean} error false
              @apiSuccess {String} message 返回消息
       """
    message = {}

    def get(self, request):
        if request.method == 'GET':
            oid = request.GET.get('suite_id')
            if oid:

                                try:
                                    suite = Suites.objects.get(suite_id=oid)
                                except:
                                    self.message = {
                                        'code': 1,
                                        "error": True,
                                        'msg': "The suite id is wrong"
                                    }
                                    return JsonResponse(self.message, safe=False)
                                else:
                                    suite_name = suite.suite_name
                                    suite_status = suite.status
                                    suite_description = suite.suite_description
                                    self.message = {
                                        'suite_name': suite_name,
                                        'suite_status': suite_status,
                                        'suite_description': suite_description,
                                        "code": 0,
                                        "error": True,
                                        "msg": 'success'
                                    }
                                    if self.message['suite_name']:
                                        return JsonResponse(self.message, safe=False)
                                    else:
                                        self.message = {
                                            'code': 1,
                                            "error": True,
                                            'msg': "suite data not found"
                                        }
                                        return JsonResponse(self.message, safe=False)

            else:
                self.message = {
                    'code': 1,
                    "error": True,
                    'msg': "suite id is not specified"
                }
                return JsonResponse(self.message, safe=False)

        else:
            self.message["code"] = 1
            self.message["error"] = True
            self.message["msg"] = 'method not allowed'
            return JsonResponse(self.message, safe=False)


# 删除套件
class SuiteDelete(APIView):
    """
        @api {DELETE} /SuiteDelete?suite_id=XXX/ 删除指定套件
        @apiVersion 1.0.0
        @apiDescription 删除指定套件
        @apiName SuiteDelete
        @apiGroup InterfaceTest
        @apiParam {Number} suite_id 套件ID
        @apiSuccessExample  请求成功
        HTTP/1.1 200 OK
        {
            "code": 0,
            "error": false,
            "msg": u'success'
        }
        @apiSuccess {Number} code 0
        @apiSuccess {Boolean} error false
        @apiSuccess {String} message 返回消息
    """
    message = {}

    def delete(self, request):
        suite_id = request.data['suite_id']
        if suite_id:

                    try:
                        file_path = Suites.objects.get(suite_id=suite_id).robotfile
                    except:
                        self.message = {
                            'code': 1,
                            "error": True,
                            'msg': "suite id is wrong"
                        }
                        return JsonResponse(self.message, safe=False)
                    else:
                        if os.path.exists(file_path):
                            os.remove(file_path)
                        else:
                            self.message = {
                                'code': 1,
                                "error": True,
                                'msg': "suite file is not exist"
                            }
                            return JsonResponse(self.message, safe=False)
                        try:
                            Suites.objects.filter(suite_id=suite_id).delete()
                            TestsuiteResults.objects.filter(suite_id=suite_id).delete()
                            TestcaseResults.objects.filter(suite_id=suite_id).delete()
                        except:
                            self.message["code"] = 1
                            self.message["error"] = True
                            self.message['msg'] = 'fail to Delete'
                            return JsonResponse(self.message, safe=False)
                        else:
                            self.message["code"] = 0
                            self.message["error"] = False
                            self.message["msg"] = 'success'
                            return JsonResponse(self.message, safe=False)
        else:
            self.message = {
                'code': 1,
                "error": True,
                'msg': "suite id is not specified"
            }
            return JsonResponse(self.message, safe=False)


# 获取当前套件下用例列表
class GetCaseList(APIView):
    """
          @api {GET} /GetCaseList?suite_id=XXX/ 获取套件下用例列表
          @apiVersion 1.0.0
          @apiDescription 获取套件下用例列表
          @apiName GetCaseList
          @apiGroup InterfaceTest
          @apiParam {Number} suite_id 套件ID
          @apiSuccessExample  请求成功
          HTTP/1.1 200 OK
            {
                "data": [
                    {
                        "id": 21,
                        "case_id": "TC_INT_001",
                        "case_name": " 获取登录页",
                        "case_description": null,
                        "case_method": "",
                        "case_service_id": null,
                        "case_project_id": null,
                        "case_creator": null,
                        "case_comments": null,
                        "case_createtime": null,
                        "case_status": "FAIL"
                    },
                    {
                        "id": 22,
                        "case_id": "TC_INT_002",
                        "case_name": " createsession",
                        "case_description": null,
                        "case_method": "",
                        "case_service_id": null,
                        "case_project_id": null,
                        "case_creator": null,
                        "case_comments": null,
                        "case_createtime": null,
                        "case_status": "PASS"
                    }

                ],
                "code": 0,
                "error": false,
                "msg": "success"
            }
          @apiSuccess {Array} data  数据列表
          @apiSuccess {Number} code 0
          @apiSuccess {Boolean} error false
          @apiSuccess {String} message 返回消息
    """

    message = {}

    # 获取数据
    def get(self, request):
        if request.method == 'GET':
            oid = request.GET.get('suite_id')
            if oid:
                S_id = oid.replace(" ", "")
                try:
                    cases = InterfaceCases.objects.filter(suite_id=S_id)
                except:

                    self.message = {
                        'code': 1,
                        "error": True,
                        'msg': "the specified suite has no case"
                    }
                    return JsonResponse(self.message, safe=False)
                else:
                    if cases:
                        data = []
                        for case in cases:
                            id = case.id
                            case_id = case.case_id
                            case_name = case.case_name
                            case_description = case.description
                            case_method = case.method
                            case_service_id = case.service_id
                            case_project_id = case.project_id
                            case_creator = case.testcases_creator
                            case_createtime = case.testcases_createtime
                            case_status = case.status
                            data.append({
                                'id': id,
                                'case_id': case_id,
                                'case_name': case_name,
                                'case_description': case_description,
                                'case_method': case_method,
                                'case_service_id': case_service_id,
                                'case_project_id': case_project_id,
                                'case_creator': case_creator,
                                'case_comments': case_description,
                                'case_createtime': case_createtime,
                                'case_status': case_status,
                            })
                        self.message['data'] = data
                        if self.message:
                            self.message["code"] = 0
                            self.message["error"] = False
                            self.message["msg"] = 'success'
                        else:
                            self.message = {
                                "code": 1,
                                "error": True,
                                "msg": 'no case data found'
                            }
                    else:
                        self.message = {
                            "code": 1,
                            "error": True,
                            'msg': "No case in this suite"
                        }
                    return JsonResponse(self.message, safe=False)

            else:
                self.message = {
                    'code': 1,
                    "error": True,
                    'msg': "suite id is not specified"
                }
                return JsonResponse(self.message, safe=False)

        else:
            self.message["code"] = 1
            self.message["error"] = True
            self.message["msg"] = 'method not allowed'
            return JsonResponse(self.message, safe=False)


# 获取服务列表
class GetServiceList(APIView):
    message = {}

    def get(self, request):
        data = []
        try:
            service = Services.objects.all().order_by('id')
        except:
            self.message = {
                'code': 1,
                "error": True,
                'msg': "Service id is not found"
            }
            return JsonResponse(self.message, safe=False)
        else:
            for item in service:
                data.append({
                    'service_id': item.service_id,
                    'service_name': item.service_name,
                    'service_description': item.service_description,
                    'service_status': item.status,
                    'service_creator': item.service_creator,
                    'service_createtime': item.service_createtime
                }),
            self.message['data'] = data
            self.message['code'] = 0
            self.message['error'] = False
            self.message['msg'] = "success"
            return JsonResponse(self.message, safe=False)


# 获取服务信息
class GetServiceMsg(APIView):
    """
              @api {GET} /SuiteMsg?suite_id=XXX/ 获取服务信息
              @apiVersion 1.0.0
              @apiDescription 获取服务信息
              @apiName GetSuiteMsg
              @apiGroup InterfaceTest
              @apiParam {Number} service_id 服务ID
              @apiSuccessExample  请求成功
              HTTP/1.1 200 OK
              {
                  "suite_name": "\u65e5\u671f",
                  "suite_status": "3",
                  "suite_comments": "eqwewqe",
                  "code": 0,
                  "error": false,
                  "msg": u'success'
              }
              @apiSuccess {String} suite_name  套件名
              @apiSuccess {String} suite_status  套件状态
              @apiSuccess {String} suite_comments  套件说明
              @apiSuccess {Number} code 0
              @apiSuccess {Boolean} error false
              @apiSuccess {String} message 返回消息
       """
    message = {}

    def get(self, request):
        if request.method == 'GET':
            oid = request.GET.get('service_id')
            if oid:
                try:
                    s_msg = Services.objects.get(service_id=oid)
                except:
                    self.message = {
                            'code': 1,
                            "error": True,
                            'msg': "service id is not found"
                        }
                    return JsonResponse(self.message, safe=False)
                else:
                    self.message = {
                        'service_name': s_msg.service_name,
                        'service_status': s_msg.status,
                        'service_description': s_msg.service_description,
                        "code": 0,
                        "error": True,
                        "msg": 'success'
                    }
                    if self.message['service_name']:
                        return JsonResponse(self.message, safe=False)
                    else:
                        self.message = {
                            'code': 1,
                            "error": True,
                            'msg': "suite data not found"
                        }
                        return JsonResponse(self.message, safe=False)
            else:
                self.message = {
                    'code': 1,
                    "error": True,
                    'msg': "suite id is not specified"
                }
                return JsonResponse(self.message, safe=False)

        else:
            self.message["code"] = 1
            self.message["error"] = True
            self.message["msg"] = 'method not allowed'
            return JsonResponse(self.message, safe=False)


# 更新服务信息
class ServiceUpdate(APIView):
    """
           @api {POST} /ServiceUpdate/ 更新服务信息
           @apiVersion 1.0.0
           @apiDescription 更新服务信息
           @apiName ServiceUpdate
           @apiGroup InterfaceTest
           @apiParam {Number} service_id 服务ID
           @apiParam {string} status 服务状态
           @apiParam {string} comment 服务说明
           @apiSuccessExample  请求成功
           HTTP/1.1 200 OK
           {
                "id": "4",
                "code": 1,
                "error": false
                "msg": " success"
            }
           @apiSuccess {String} suite_name  套件ID
           @apiSuccess {Number} code 0
           @apiSuccess {Boolean} error false
           @apiSuccess {String} message 返回消息
    """
    message = {}

    def post(self, request):
        if request.method == 'POST':
            service_id = request.POST.get('service_id')
            service_name = request.POST.get('service_name')
            service_status = request.POST.get('service_status')
            service_description = request.POST.get('service_description')
            if service_name or service_description or service_status:
                try:
                    Services.objects.filter(service_id=service_id).update(service_name=service_name, status=service_status, service_description=service_description)
                except:
                    self.message = {
                        'code': 1,
                        "error": True,
                        'msg': " service id is wrong"
                    }
                    return JsonResponse(self.message, safe=False)
                else:
                    self.message = {
                        'code': 0,
                        "error": False,
                        'msg': "success"
                    }
                    return JsonResponse(self.message, safe=False)
            else:
                self.message = {
                    'code': 1,
                    "error": True,
                    'msg': "service id is not specified"
                }
                return JsonResponse(self.message, safe=False)
        else:
            self.message["code"] = 1
            self.message["error"] = True
            self.message["msg"] = 'method not allowed'
            return JsonResponse(self.message, safe=False)


# 执行用例
class Execute(APIView):
    """
           @api {POST} /Execute/?id=XXX/ 执行用例
           @apiVersion 1.0.0
           @apiDescription 执行用例
           @apiName Execute
           @apiGroup InterfaceTest
           @apiParam {Number} id 套件ID或者用例ID
           @apiParam {string} type 类型：suite or case
           @apiSuccessExample  请求成功(case)
           HTTP/1.1 200 OK
           {
                "case": {
                    "id": "24",
                    "code": 0,
                    "error": false,
                    "msg": "success"
                }
            }
           @apiSuccessExample  请求成功(suite)
           HTTP/1.1 200 OK
           {
                "suite": {
                    "id": "4",
                    "code": 0,
                    "error": false,
                    "msg": "success"
                }
            }
           @apiSuccess {Number} id id值
           @apiSuccess {Number} code 0
           @apiSuccess {Boolean} error false
           @apiSuccess {String} message 返回消息
    """
    message = {}

    def post(self, request):
        input_type = request.POST.get('type')
        S_id = request.POST.get('suite_id')
        ID_list = json.loads(request.POST.get('SelectsIdList'))
        path = 'results'
        if input_type and ID_list:
                    if input_type == 'suite':
                            # try to get data
                            for id in ID_list:
                                try:
                                    suite_ins = Suites.objects.get(suite_id=id)
                                except:
                                    self.message = {
                                        'code': 1,
                                        "error": True,
                                        'msg': "The suite id is not existaaa"
                                    }
                                    return JsonResponse(self.message, safe=False)
                                else:
                                    if suite_ins:
                                        suite_name = suite_ins.suite_name
                                        lock.acquire()
                                        flag = 0
                                        # robot.run(RFfile.robotfile, stderr=True, outputdir=path)
                                        os.system("robot -d ./results " + suite_ins.robotfile)
                                        lock.release()
                                        report_file = path + "/output.xml"
                                        if os.path.exists(report_file):
                                            run_id = str(random.randint(0, 9999999999)).zfill(10)
                                            report_data = analyze_xml(path + "/output.xml")
                                            if re.search("<>", report_data[suite_name]):
                                                suite_data = report_data[suite_name].split("<>")
                                            else:
                                                self.message['suite'] = {
                                                    "id": id,
                                                    'code': 1,
                                                    "error": True,
                                                    'msg': "unknow suite id"
                                                }
                                                return JsonResponse(self.message, safe=True)
                                            passed = int(suite_data[-2])
                                            failed = int(suite_data[-1])
                                            count = passed + failed
                                            status = suite_data[0]
                                            start_time = suite_data[1]
                                            end_time = suite_data[2]
                                            try:
                                                TestsuiteResults.objects.create(run_id=run_id, suite_id=id, passed=passed,
                                                                                failed=failed, count=count, status=status,
                                                                                start_time=start_time, end_time=end_time)
                                            except:
                                                self.message['suite'] = {
                                                    "id": id,
                                                    'code': 1,
                                                    "error": True,
                                                    'msg': "unknow suite id"
                                                }
                                            else:
                                                for key, value in report_data.items():
                                                    if re.search("TC_INT_\d+:", key):
                                                        case_id = re.search("(TC_INT_\d+):.*", key).group(1)
                                                        case_data = report_data[key].split("<>")
                                                        status = case_data[0]
                                                        start_time = case_data[1]
                                                        end_time = case_data[2]
                                                        message = case_data[-1]
                                                        try:
                                                            TestcaseResults.objects.create(run_id=run_id, suite_id=id,
                                                                                           case_id=case_id,
                                                                                           run_type="suite", status=status,
                                                                                           start_time=start_time,
                                                                                           end_time=end_time,
                                                                                           logs=message)

                                                        except:
                                                            self.message['suite'] = {
                                                                "id": id,
                                                                'code': 1,
                                                                "error": True,
                                                                'msg': "unknow suite id"
                                                            }
                                                        else:
                                                            try:
                                                                InterfaceCases.objects.filter(id=case_id).update(
                                                                    status=status)
                                                            except:
                                                                self.message['suite'] = {
                                                                    "id": id,
                                                                    'code': 1,
                                                                    "error": True,
                                                                    'msg': "insert case status failed"
                                                                }
                                                            else:
                                                                self.message['suite'] = {

                                                                    "id": id,
                                                                    'code': 0,
                                                                    "error": False,
                                                                    'msg': "success"
                                                                }
                                                    else:
                                                        continue

                                                for key, value in report_data.items():
                                                    if re.match("^TC_INT_\d+$", key):
                                                         flag = flag+1
                                                         try:
                                                            TestcaseResults.objects.filter(case_id=key,
                                                                                           run_id=run_id).update(
                                                                logs=report_data[key])
                                                         except:
                                                             self.message['suite'] = {
                                                                 "id": key,
                                                                 'code': 1,
                                                                 "error": True,
                                                                 'msg': "no report file"
                                                             }
                                                         else:
                                                            self.message['suite'] = {

                                                                "id": id,
                                                                'code': 0,
                                                                "error": False,
                                                                'msg': "success"
                                                            }
                                                if flag != 0:
                                                    try:
                                                        Suites.objects.filter(suite_id=id).update(status=1)
                                                    except:
                                                        pass
                                                else:
                                                    Suites.objects.filter(suite_id=id).update(status=0)
                                        else:
                                            self.message['suite'] = {
                                                "id": id,
                                                'code': 1,
                                                "error": True,
                                                'msg': "no report file"
                                            }
                                    else:
                                        self.message['suite'] = {
                                            "id": id,
                                            'code': 0,
                                            "error": False,
                                            'msg': "suite is not exist"
                                        }
                                return JsonResponse(self.message, safe=True)

                    elif input_type == 'case':
                        id = ID_list[0]
                        self.message = {}
                        if isinstance(id, str):
                            case_ins = ""
                            try:
                                case_ins = InterfaceCases.objects.get(case_id=id, suite_id=S_id)
                            except:
                                self.message['case'] = {
                                    "id": id,
                                    'code': 1,
                                    "error": True,
                                    'msg': "unknow case id"
                                }
                            else:
                                if case_ins:
                                    suite_id = S_id
                                    case_id = id
                                    # RFfile = Suites.objects.get(suite_id=InterfaceCases.objects.get(id=id).suite_id)
                                    RFfile = Suites.objects.get(suite_id=suite_id)
                                    lock.acquire()
                                    robot.run(RFfile.robotfile, test=[case_id + "*"], outputdir=path)
                                    lock.release()
                                    report_file = path + "/output.xml"
                                    if os.path.exists(report_file):
                                        run_id = str(random.randint(0, 9999999999)).zfill(10)
                                        report_data = analyze_xml(path + "/output.xml")
                                        for key, value in report_data.items():
                                            if re.search("TC_INT_\d+", key):
                                                case_data = report_data[key].split("<>")
                                                status = case_data[0]
                                                start_time = case_data[1]
                                                end_time = case_data[2]
                                                message = case_data[-1]
                                                # add data
                                                try:
                                                    TestcaseResults.objects.create(run_id=run_id, suite_id=S_id,
                                                                                   case_id=id,
                                                                                   run_type="case", status=status,
                                                                                   start_time=start_time,
                                                                                   end_time=end_time,
                                                                                   logs=message)
                                                except:
                                                    self.message['case'] = {
                                                        "id": id,
                                                        'code': 1,
                                                        "error": True,
                                                        'msg': "unknow case id"
                                                    }
                                                else:
                                                    try:
                                                        InterfaceCases.objects.filter(case_id=id).update(status=status)
                                                    except:
                                                        self.message['case'] = {
                                                            "id": id,
                                                            'code': 1,
                                                            "error": True,
                                                            'msg': "insert case status failed"
                                                        }
                                                    else:
                                                        self.message['case'] = {
                                                            "id": id,
                                                            'code': 0,
                                                            "error": False,
                                                            'msg': "success"
                                                        }

                                    return JsonResponse(self.message, safe=True)
                                else:
                                    self.message['case'] = {
                                        "id": id,
                                        'code': 1,
                                        "error": True,
                                        'msg': "unknow case id"
                                    }

                        elif isinstance(id, list):
                            print("TODO")
                        else:
                            print("Unknown type id")

                    else:
                        self.message = {
                            "id": id,
                            'code': 1,
                            "error": True,
                            'msg': "unknow type value"
                        }
                    return JsonResponse(self.message, safe=True)
        else:
            self.message = {
                "id": ID_list,
                'code': 1,
                "error": True,
                'msg': "The suite id or the execute type is not specified"
            }
            return JsonResponse(self.message, safe=True)


# 获取运行结果
class GetResult(APIView):
    """
              @api {GET} /GetResult?id=XXX&type=XXX/ 获取运行结果
              @apiVersion 1.0.0
              @apiDescription 获取运行结果
              @apiName GetResult
              @apiGroup InterfaceTest
              @apiParam {Number} id 套件ID或者用例ID
              @apiParam {string} type 类型：suite or case
              @apiSuccessExample  请求成功(case)
              HTTP/1.1 200 OK
              {
                    "case": {
                        "case_name": " Test weather",
                        "status": "PASS",
                        "logs": "",
                        "start_time": "20180622 16:43:26.240",
                        "end_time": "20180622 16:43:26.466"
                    },
                    "code": 0,
                    "error": false,
                    "msg": "success"
               }

              @apiSuccessExample  请求成功(suite)
              HTTP/1.1 200 OK
              {
                    "suite": {
                        "status": "FAIL",
                        "passed": 3,
                        "failed": 2,
                        "count": 5,
                        "rate": "0.6%",
                        "start_time": "20180531 14:01:24.178",
                        "end_time": "20180531 14:01:25.138"
                    },
                    "cases": [
                                {
                                    "case_name": " 获取登录页",
                                    "logs": "Keyword '回应' expected 0 arguments, got 3."
                                },
                                {
                                    "case_name": " createsession",
                                    "logs": "20180531 14:01:24.597"
                                },
                                {
                                    "case_name": " get",
                                    "logs": "20180531 14:01:24.866"
                                },
                                {
                                    "case_name": " post",
                                    "logs": "20180531 14:01:25.136"
                                },
                                {
                                    "case_name": "登录",
                                    "logs": "Keyword '登录' expected 5 arguments, got 2."
                                }
                             ],
                    "code": 0,
                    "error": false,
                    "msg": "success"
               }
              @apiSuccess {Number} id id值
              @apiSuccess {Number} code 0
              @apiSuccess {Boolean} error false
              @apiSuccess {String} message 返回消息
       """
    message = {}

    # 获取数据
    def get(self, request):
        if request.method == 'GET':
            oid = request.GET.get('id')
            search_type = request.GET.get('type')
            if oid:
                S_id = oid.replace(" ", "")
                if S_id.isdigit():
                    if len(S_id) >= 10:
                        self.message = {
                            'code': 1,
                            "error": True,
                            'msg': "The suite id is too long"
                        }
                        return JsonResponse(self.message, safe=False)
                    else:
                        if search_type == "suite":
                            try:
                                suite_result = TestsuiteResults.objects.filter(suite_id=S_id).order_by('id').latest(
                                    'id')
                            except:

                                self.message = {
                                    'code': 1,
                                    "error": True,
                                    'msg': "suite id is wrong "
                                }
                                return JsonResponse(self.message, safe=False)
                            else:
                                self.message["suite"] = {
                                    "suite_id": S_id,
                                    "status": suite_result.status,
                                    "passed": suite_result.passed,
                                    "failed": suite_result.failed,
                                    "count": suite_result.count,
                                    "rate": str(round(100 * (float(suite_result.passed) / float(suite_result.count)), 2)) + '%',
                                    "start_time": suite_result.start_time,
                                    "end_time": suite_result.end_time,
                                }

                            try:
                                case_result = TestcaseResults.objects.filter(run_id=suite_result.run_id)
                            except:
                                pass
                            else:
                                midd_array = []
                                for case in case_result:
                                    case_name = InterfaceCases.objects.get(id=case.case_id).case_name
                                    midd_array.append({"case_name": case_name,
                                                       "logs": case.logs})
                                self.message['cases'] = midd_array
                                if self.message:
                                    self.message["code"] = 0
                                    self.message["error"] = False
                                    self.message["msg"] = 'success'
                                else:
                                    self.message["code"] = 1
                                    self.message["error"] = True
                                    self.message["msg"] = 'run failed'
                            return JsonResponse(self.message, safe=False)

                        elif search_type == "case":
                            try:
                                case_result = TestcaseResults.objects.filter(case_id=S_id).order_by('id').latest('id')
                                case_id = InterfaceCases.objects.get(id=S_id).case_id
                                suite_id = InterfaceCases.objects.get(id=S_id).suite_id
                                case_name = InterfaceCases.objects.get(id=S_id).case_name
                            except:
                                self.message = {
                                    'code': 1,
                                    "error": True,
                                    'msg': "case id is wrong"
                                }
                                return JsonResponse(self.message, safe=False)
                            else:
                                self.message['case'] = {
                                    "suite_id": suite_id,
                                    "case_id": case_id,
                                    "case_name": case_name,
                                    "status": case_result.status,
                                    "logs": case_result.logs,
                                    "start_time": case_result.start_time,
                                    "end_time": case_result.end_time,
                                }
                            if self.message:
                                self.message["code"] = 0
                                self.message["error"] = False
                                self.message["msg"] = 'success'
                            else:
                                self.message["code"] = 1
                                self.message["error"] = True
                                self.message["msg"] = 'run failed'
                            return JsonResponse(self.message, safe=False)

                        else:
                            self.message = {
                                'code': 1,
                                "error": True,
                                'msg': "type is not specified"
                            }
                            return JsonResponse(self.message, safe=False)

                else:
                    self.message = {
                        'code': 1,
                        "error": True,
                        'msg': "The type of id is not allowed"
                    }
                    return JsonResponse(self.message, safe=False)
            else:
                self.message = {
                    'code': 1,
                    "error": True,
                    'msg': "id is not specified"
                }
                return JsonResponse(self.message, safe=False)

        else:
            self.message["code"] = 1
            self.message["error"] = True
            self.message["msg"] = 'method not allowed'
            return JsonResponse(self.message, safe=False)


# 更新套件信息
class SuiteUpdate(APIView):
    """
           @api {POST} /SuiteUpdate/ 更新套件信息
           @apiVersion 1.0.0
           @apiDescription 更新套件信息
           @apiName SuiteUpdate
           @apiGroup InterfaceTest
           @apiParam {Number} suite_id 套件ID
           @apiParam {string} status 套件状态
           @apiParam {string} comment 套件说明
           @apiSuccessExample  请求成功
           HTTP/1.1 200 OK
           {
                "id": "4",
                "code": 1,
                "error": false
                "msg": " success"
            }
           @apiSuccess {String} suite_name  套件ID
           @apiSuccess {Number} code 0
           @apiSuccess {Boolean} error false
           @apiSuccess {String} message 返回消息
    """
    message = {}

    def post(self, request):
        if request.method == 'POST':
            suite_id = request.POST.get('suite_id')
            suite_status = request.POST.get('status')
            suite_description = request.POST.get('suite_description')
            if suite_description:
                   try:
                       Suites.objects.filter(suite_id=suite_id).update(
                           suite_description=suite_description,
                       )
                   except:
                       self.message = {
                           'suite_id': suite_id,
                           'code': 1,
                           "error": True,
                           'msg': " Data update Error"
                       }
                       return JsonResponse(self.message, safe=False)
                   else:
                       self.message["suite_id"] = suite_id
                       self.message["code"] = 0
                       self.message["error"] = False
                       self.message["msg"] = 'success'
                       return JsonResponse(self.message, safe=False)
            else:
                self.message = {
                    'id': id,
                    'code': 1,
                    "error": True,
                    'msg': "suite description is not specified"
                }
                return JsonResponse(self.message, safe=False)
        else:
            self.message["code"] = 1
            self.message["error"] = True
            self.message["msg"] = 'method not allowed'
            return JsonResponse(self.message, safe=False)


# 上传套件
class SuiteUpload(APIView):
    """
              @api {POST} /SuiteUpload/ 上传套件
              @apiVersion 1.0.0
              @apiDescription 上传套件
              @apiName SuiteUpload
              @apiGroup InterfaceTest
              @apiParam {file} file 套件文件
              @apiParam {string} service_id 服务ID
              @apiSuccessExample  请求成功
              HTTP/1.1 200 OK
              {
                   "code": 0,
                   "error": false
                   "msg": " success"
               }
              @apiSuccess {Number} code 0
              @apiSuccess {Boolean} error false
              @apiSuccess {String} message 返回消息
       """
    message = {}

    def post(self, request):
        if Suites.objects.all().last():
            availed_id = Suites.objects.all().last().id + 1
            availed_TSid = "TS_INT_" + str(availed_id)
        else:
            availed_id = 1
            availed_TSid = "TS_INT_1"

        if request.method == 'POST':
            S_id = request.POST.get('service_id')
            obj = request.FILES.get('file')
            file_path = os.path.join('uploads', obj.name)
            file_name = re.sub("\.\w+", "", obj.name)
            if S_id:
                if os.path.exists(file_path):
                    self.message = {
                        "code": 1,
                        "error": True,
                        "msg": 'robot file already exist'
                    }
                    return JsonResponse(self.message, safe=False)
                else:
                    f = open(os.path.join('uploads', obj.name), 'wb')
                    for line in obj.chunks():
                        f.write(line)
                    f.close()
                    if Suites.objects.filter(suite_name=file_name):
                        self.message = {
                            "code": 1,
                            "error": True,
                            "msg": 'suite name already exist'
                        }
                        return JsonResponse(self.message, safe=False)
                    else:

                        # alalyze file
                        result = analyze_robot(file_path, availed_TSid)
                        if result != 0:
                            os.remove(file_path)
                            self.message = {
                                "code": 2,
                                "error": True,
                                "msg": 'The robot file‘s format is wrong',
                            }
                            return JsonResponse(self.message, safe=False)
                        else:
                            # add data
                            try:
                                Suites.objects.create(
                                    id=availed_id,
                                    suite_id=availed_TSid,
                                    suite_name=file_name,
                                    suite_description='',
                                    service_id=S_id,
                                    # project_id='',
                                    suite_creator="",
                                    suite_createtime=time.strftime("%Y/%m/%d %H:%M:%S", time.localtime()),
                                    robotfile=os.path.join('uploads', obj.name),
                                    status=3)
                            except:
                                self.message = {
                                    "code": 1,
                                    "error": True,
                                    "msg": 'upload error'
                                }
                                os.remove(file_path)
                                return JsonResponse(self.message, safe=False)
                            else:

                                self.message = {
                                    "code": 0,
                                    "error": False,
                                    "msg": 'upload success'
                                }
                                return JsonResponse(self.message, safe=False)

            else:
                self.message = {"code": 1,
                                "error": True,
                                "msg": 'service ID is not specified'
                                }
                return JsonResponse(self.message, safe=False)
        else:
            self.message = {"code": 1,
                            "error": True,
                            "msg": 'method not allowed'
                            }
            return JsonResponse(self.message, safe=False)


# 新建服务
class AddService(APIView):
    """
     create new service
    """
    message = {}

    def post(self, request):
        if request.method == 'POST':
            service_name = request.POST.get('service_name')
            service_description = request.POST.get('service_description')
            service_status = request.POST.get('service_status')
            if service_name or service_description or service_status:
                if Services.objects.all():
                    available_sid = Services.objects.all().latest('id')
                    available_id = re.search("SID_(\d+)", available_sid.service_id).group(1)
                    available_id = str(int(available_id) + 1)
                    available_newsid = "SID_" + available_id
                else:
                    available_newsid = "SID_1"
                try:
                    Services.objects.create(service_id=available_newsid, service_name=service_name,
                                            service_description=service_description,
                                            status=service_status,
                                            service_createtime=datetime.datetime.now())
                except:
                    self.message = {
                        'code': 1,
                        "error": True,
                        'msg': "creating service is failed"
                    }
                    return JsonResponse(self.message, safe=False)
                else:
                    self.message = {
                        'code': 0,
                        "error": False,
                        'msg': "success"
                     }
            return JsonResponse(self.message, safe=False)


# 删除服务
class ServiceDelete(APIView):
    """
        @api {DELETE} /SuiteDelete?suite_id=XXX/ 删除指定服务
        @apiVersion 1.0.0
        @apiDescription 删除指定服务
        @apiName SuiteDelete
        @apiGroup InterfaceTest
        @apiParam {Number} service_id 服务ID
        @apiSuccessExample  请求成功
        HTTP/1.1 200 OK
        {
            "code": 0,
            "error": false,
            "msg": u'success'
        }
        @apiSuccess {Number} code 0
        @apiSuccess {Boolean} error false
        @apiSuccess {String} message 返回消息
    """
    message = {}

    def delete(self, request):
        id = request.data['service_id']
        if id:
            try:
                Services.objects.filter(service_id=id).delete()
            except:
                self.message = {
                    'code': 1,
                    "error": True,
                    'msg': "Delete failed"
                }
                return JsonResponse(self.message, safe=False)
            else:
                self.message = {
                    'code': 0,
                    "error": False,
                    'msg': "success"
                }
                return JsonResponse(self.message, safe=False)
        else:
            self.message = {
                'code': 1,
                "error": True,
                'msg': "service id is wrong"
            }
            return JsonResponse(self.message, safe=False)


# 加载robot file
def analyze_robot(file, suite_id):
    flag = 0
    if file:
        f = open(file, "r", encoding="utf-8")
        for i in f:
            if re.search("(TC_INT_\d+)", i):
                flag = flag +1
                Case_ID = re.search("(TC_INT_\d+)", i).group(1)
                Case_Name = re.search("TC_INT_\d+:(.*)", i).group(1)
                try:
                    InterfaceCases.objects.create(suite_id=suite_id, case_id=Case_ID, case_name=Case_Name)
                except:
                    f.close()
                    return 1
                else:
                    continue
            else:
                pass
        f.close()
        if flag != 0:
            return 0
        else:
            return 1
    else:
        return 1


# xml文件解析
def analyze_xml(file_path):
    data = {}
    try:
        import xml.etree.cElementTree as ET
    except ImportError:
        import xml.etree.ElementTree as ET
    tree = ET.parse(file_path)
    root = tree.getroot()
    suite_name = root.find("suite").attrib["name"]
    for i in root.find("suite"):
        if i.tag == 'test':
            for j in i:
                if j.tag == 'status':
                    if j.attrib['status'] == "FAIL":
                        data[i.attrib['name']] = j.attrib['status'] + "<>" + j.attrib['starttime'] + "<>" + j.attrib[
                            'endtime'] + "<>" + j.text
                    else:
                        data[i.attrib['name']] = j.attrib['status'] + "<>" + j.attrib['starttime'] + "<>" + j.attrib[
                            'endtime'] + "<>" + ""
                elif j.tag == 'kw':
                    for k in j:
                        if k.tag == 'msg' and k.attrib['level'] == 'ERROR':
                            case_id = re.search("(TC_INT_\d+).*", i.attrib['name']).group(1)
                            data[case_id] = k.text
                        else:
                            pass

        if i.tag == 'status':
            data[suite_name] = i.attrib['status'] + "<>" + i.attrib['starttime'] + "<>" + i.attrib['endtime']
    for k in root.find("statistics"):
        if k.tag == "suite":
            for m in k:
                if m.tag == "stat":
                    data[suite_name] = data[suite_name] + "<>" + m.attrib['pass'] + "<>" + m.attrib['fail']
    return data



# 服务列表页面
def ServiceList(request):
    return render(request, 'interface_test/ServiceList.html',
                  context={'listatus': 'ServiceList', 'edit': 1, 'delete': 1, 'modify': 1})


# suite 列表页面
def SuiteList(request):
    service_id = request.GET.get("service_id")
    return render(request, 'interface_test/SuiteList.html', context={'listatus': 'SuiteList', 'edit': 1, 'delete': 1, 'modify': 1, 'service_id':service_id})


# case 列表页面
def CaseList(request):
    id = request.GET.get("suite_id")
    if id:
        return render(request, 'interface_test/CaseList.html', context={'listatus': 'CaseList', 'suite_id': id})
    else:
        cases = InterfaceCases.objects.all()
        return render(request, 'interface_test/CaseList.html', context={'listatus': 'CaseList', "case": cases})


# 运行结果页面
def Results(request):
    resultId = request.GET.get("id")
    resultType = request.GET.get("type")
    data={}
    if resultType == 'suite':
        try:
            suite_result = TestsuiteResults.objects.filter(suite_id=resultId).order_by('id').latest('id')
            suitecase_result = TestcaseResults.objects.filter(suite_id=resultId, run_id=suite_result.run_id, status='FAIL').order_by('id')
        except:

            message = {
                'code': 1,
                "error": True,
                'msg': "suite id is wrong"
            }
            return render(request, 'interface_test/pages-error-404.html')
        else:
            for case in suitecase_result:
                case_name = \
                    InterfaceCases.objects.get(suite_id=case.suite_id, case_id=case.case_id).case_name
                data[case.case_id+':'+case_name] = case.logs
            return render(request, 'interface_test/result.html', context={'suite_result': data, 'listatus': 'suiteresult', 'type': 'suite', 'suite_id': resultId, 'start_time': suite_result.start_time,  'end_time': suite_result.end_time, 'passed': suite_result.passed, 'failed': suite_result.failed, 'rate': str(round(100 * (float(suite_result.passed) / (float(suite_result.passed)+float(suite_result.failed))), 2)) + '%'})
    elif resultType == 'case':
        try:
            case_result = TestcaseResults.objects.filter(case_id=resultId).order_by('id').latest('id')
        except:

            message = {
                'code': 1,
                "error": True,
                'msg': "case id is wrong"
            }
            return JsonResponse(message, safe=False)
        else:
            if case_result.logs:
                data[resultId] = case_result.logs
            else:
                data[resultId] = 'None'

        return render(request, 'interface_test/result.html', context={'case_result': data, 'listatus': 'caseresult', 'type': 'case', 'case_id': resultId, 'start_time': case_result.start_time,  'end_time': case_result.end_time, 'status': case_result.status})
    else:
        return HttpResponse("type error")
