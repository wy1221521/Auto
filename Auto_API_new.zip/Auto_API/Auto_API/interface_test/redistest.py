import redis
conn = redis.Redis(host='10.0.0.10',port=6379)
conn.set('k1','v1') # 向远程redis中写入了一个键值对
val = conn.get('k1') # 获取键值对
print(val)