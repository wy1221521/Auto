from django.db import models


# Create your models here.


class Services(models.Model):
    objects = None
    id = models.AutoField(primary_key=True)
    service_id = models.CharField(max_length=20)
    service_name = models.CharField(max_length=255)
    service_description = models.CharField(max_length=255, null=True)
    status = models.CharField(max_length=20, null=True)
    service_creator = models.CharField(max_length=10, null=True)
    service_createtime = models.TextField()


class Suites(models.Model):
    objects = None
    id = models.AutoField(primary_key=True)
    suite_id = models.CharField(max_length=20)
    suite_name = models.CharField(max_length=255)
    suite_description = models.CharField(max_length=255, null=True)
    service_id = models.CharField(max_length=20, null=True)
    project_id = models.IntegerField(null=True)
    status = models.CharField(max_length=20, null=True)
    robotfile = models.CharField(max_length=255, null=True)
    suite_creator = models.CharField(max_length=10, null=True)
    suite_createtime = models.TextField()


class InterfaceCases(models.Model):
    objects = None
    id = models.AutoField(primary_key=True)
    case_id = models.CharField(max_length=20, null=True)
    case_name = models.CharField(max_length=255, null=True)
    suite_id = models.CharField(max_length=20, null=True)
    method = models.CharField(max_length=10, null=True)
    service_id = models.CharField(max_length=20, null=True)
    project_id = models.IntegerField(null=True)
    testcases_creator = models.CharField(max_length=20, null=True)
    testcases_createtime = models.TextField(null=True)
    status = models.CharField(max_length=20, null=True)
    expected = models.CharField(max_length=255, null=True)
    obtained = models.CharField(max_length=255, null=True)
    description = models.TextField(null=True)


class TestsuiteResults(models.Model):
    objects = None
    run_id = models.CharField(max_length=20, null=True)
    suite_id = models.CharField(max_length=20, null=True)
    status = models.CharField(max_length=20, null=True)
    passed = models.IntegerField(null=True)
    failed = models.IntegerField(null=True)
    count = models.IntegerField(null=True)
    logs = models.CharField(max_length=255, null=True)
    start_time = models.CharField(max_length=255, null=True)
    end_time = models.CharField(max_length=255, null=True)


class TestcaseResults(models.Model):
    objects = None
    run_id = models.CharField(max_length=20, null=True)
    case_id = models.CharField(max_length=10, null=True)
    suite_id = models.CharField(max_length=10, null=True)
    run_type = models.CharField(max_length=10, null=True)
    status = models.CharField(max_length=10, null=True)
    logs = models.CharField(max_length=255, null=True)
    start_time = models.CharField(max_length=255, null=True)
    end_time = models.CharField(max_length=255, null=True)
