from rest_framework import serializers
from .models import Suites, InterfaceCases


class SuiteSerializer(serializers.ModelSerializer):
# class SuiteSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Suites
        fields = '__all__'
