from django.apps import AppConfig


class InterfaceTestConfig(AppConfig):
    name = 'interface_test'
