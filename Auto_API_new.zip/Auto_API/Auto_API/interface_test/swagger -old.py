from rest_framework.decorators import renderer_classes, api_view
from rest_framework_swagger.renderers import OpenAPIRenderer, SwaggerUIRenderer
import coreapi
from rest_framework import response
# noinspection PyArgumentList
@api_view()
@renderer_classes([SwaggerUIRenderer, OpenAPIRenderer])
def schema_view(request):
    # noinspection PyArgumentList
    schema = coreapi.Document(
    title='Automation test API',
    description = 'this is a document for automation test api ',
    url='127.0.0.1:8000',
    media_type='swagger',
    content={
        'SuiteList': coreapi.Link(
            url='/SuiteList/',
            action='get',
            fields=[],
            description='获取用例套件列表'
        ),
        'UPload': coreapi.Link(
            url='/Upload/',
            action='post',
            fields=[
                coreapi.Field(
                    name='file',
                    required=True,
                    type='file',
                    location='query',
                    description='指定测试套件文件.'
                ),
            ],
            description='上传用例套件文件'
        ),
        'SuiteMsg': coreapi.Link(
            url='/SuiteMsg/',
            action='get',
            fields=[
                coreapi.Field(
                    name='suite_id',
                    required=True,
                    location='query',
                    description='指定测试套件ID'
                ),
            ],
            description='获取所选测试套件信息'
        ),

        'SuiteUpdate': coreapi.Link(
            url='/SuiteUpdate/',
            action='post',
            fields=[
                coreapi.Field(
                    name='id',
                    required=True,
                    location='query',
                    description='指定测试套件ID'
                ),
                coreapi.Field(
                    name='status',
                    required=False,
                    location='query',
                    description='修改测试套件状态'
                ),
                coreapi.Field(
                    name='comment',
                    required=False,
                    location='query',
                    description='修改测试套件描述'
                ),
            ],
            description='更新所选测试套件信息'
        ),

        'SuiteDelete': coreapi.Link(
            url='/SuiteDelete/',
            action='DELETE',
            fields=[
                coreapi.Field(
                    name='id',
                    required=True,
                    location='query',
                    description='指定删除测试套件ID'
                ),
            ],
            description='删除所选测试套件'
        ),

        'Execute': coreapi.Link(
            url='/Execute/',
            action='get',
            fields=[
                coreapi.Field(
                    name='id',
                    required=True,
                    location='query',
                    description='指定执行的测试用例'
                ),
                coreapi.Field(
                    name='type',
                    required=True,
                    location='query',
                    description='指定执行测试的类型'
                ),
            ],
            description='执行所选测试用例'
        ),

        'GetCaseList': coreapi.Link(
            url='/GetCaseList/',
            action='get',
            fields=[
                coreapi.Field(
                    name='suite_id',
                    required=True,
                    location='query',
                    description='指定套件ID'
                ),
            ],
            description='获取当前套件下用例列表'
        ),

        'GetResult': coreapi.Link(
            url='/GetResult/',
            action='get',
            fields=[
                coreapi.Field(
                    name='id',
                    required=True,
                    location='query',
                    description='指定ID'
                ),coreapi.Field(
                    name='type',
                    required=True,
                    location='query',
                    description='指定type'
                ),
            ],
            description='获取用例结果'
        ),

    }
)

    return response.Response(schema)