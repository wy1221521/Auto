"""Auto_API URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf.urls import url, include, re_path
from interface_test import views, swagger_views
from django.contrib import admin
from django.views.static import serve
from django.conf import settings

urlpatterns = [
    # home page
    url(r'^index$', views.Index, name='home'),
    #admin
    url(r'^admin/', admin.site.urls, name='admin'),
    #apidoc
    url(r'^apidoc(?P<path>.*)$', serve, {'document_root': settings.APIDOC_ROOT}),
    #swagger
    url(r'^docs/$', swagger_views.SwaggerSchemaView.as_view(), name='docs'),
    # 接口文档
    # url(r'^docs/$', swagger.schema_view, name="docs"),
    # 套件列表
    url(r'^SuiteList', views.GetSuiteView.as_view(), name='SuiteList'),
    # 编辑套件
    url(r'^GetSuiteMsg/$', views.GetSuiteMsg.as_view(), name='GetSuiteMsg'),
    # 删除套件
    url(r'^SuiteDelete/$', views.SuiteDelete.as_view(), name='SuiteDelete'),
    # 执行用例
    url(r'^Execute/$', views.Execute.as_view(), name='Execute'),
    # 获取套件用例
    url(r'^GetCaseList', views.GetCaseList.as_view(), name='GetCaSseList'),
    # 获取结果
    url(r'^GetResult', views.GetResult.as_view(), name='GetResult'),
    # 更新套件
    url(r'^SuiteUpdate/$', views.SuiteUpdate.as_view(), name='SuiteUpdate'),
    # 上传套件
    url(r'^SuiteUpload/', views.SuiteUpload.as_view(), name='upload'),
    # 获取服务
    url(r'^ServiceList/$', views.GetServiceList.as_view(), name='ServiceList'),
    # 新建服务
    url(r'^AddService/$', views.AddService.as_view(), name='AddService'),
    # 删除服务
    url(r'^ServiceDelete/$', views.ServiceDelete.as_view(), name='ServiceDelete'),
    # 编辑服务
    url(r'^GetServiceMsg/$', views.GetServiceMsg.as_view(), name='GetServiceMsg'),
    # 更新服务
    url(r'^ServiceUpdate/$', views.ServiceUpdate.as_view(), name='ServiceUpdate'),

    # 页面函数
    # 服务页
    url(r'^Services$', views.ServiceList, name='Services'),
    # 套件页
    url(r'^Suites$', views.SuiteList, name='Suites'),
    # 用例页
    url(r'^Cases$', views.CaseList, name='Cases'),
    # 结果页
    url(r'^Results$', views.Results, name='Result'),
]
