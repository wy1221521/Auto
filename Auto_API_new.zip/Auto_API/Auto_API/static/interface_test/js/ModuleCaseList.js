function initTable(x) {
    $('#ModuleCaseList').bootstrapTable({
        url: '/ModuleCaseIndex?module_name='+x ,    //请求后台的URL（*）
        method: 'get',                      //请求方式（*）
        toolbar: '#toolbar',                //工具按钮用哪个容器
        striped: true,                      //是否显示行间隔色
        cache: false,                       //是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
        pagination: true,                   //是否显示分页（*）
        sidePagination: "client",           //分页方式：client客户端分页，server服务端分页（*）
        pageNumber: 1,                      //初始化加载第一页，默认第一页
        pageSize: 10,                       //每页的记录行数（*）
        pageList: [10, 20, 50, 100],        //可供选择的每页的行数（*）
        search: true,                       //是否显示表格搜索
        strictSearch: false,                //false 模糊搜索
        showColumns: false,                 //是否显示所有的列
        showRefresh: true,                  //是否显示刷新按钮
        singleSelect: false,
        height: 800,                        //行高，如果没有设置height属性，表格自动根据记录条数觉得表格高度
        uniqueId: "uid",                    //每一行的唯一标识，一般为主键列
        showToggle: true,                   //是否显示详细视图和列表视图的切换按钮
        cardView: false,                    //是否显示详细视图
        detailView: false,                  //是否显示父子表
        clickToSelect: true,
        maintainSelected: false,
        columns: [ {
                field:'ck',
                checkbox:true,
            },{
            field: 'id',
            title: '序号',
            align: 'center',
            sortable: true,
        },  {
            field: 'test_id',
            title: '用例号',
            align: 'center',
            sortable: true,
        },  {
            field: 'topic',
            title: '主题',
            align: 'center',
            sortable: true,
        }, {
            field: 'type',
            title: '类型',
            align: 'center',
            sortable: true,
        },{
            field: 'steps',
            title: '步骤',
            align: 'center',
            sortable: true,
        }, {
            field: 'expected',
            title: '期待结果',
            align: 'center',
            sortable: true,
        },{
            field: 'status',
            title: '状态',
            align: 'center',
            sortable: true,
            formatter:StatusFormatter,
        },{
            field: 'testcases_creator',
            title: '创建者',
            align: 'center',
            sortable: true,
        },{
            field: 'testcases_createtime',
            title: '创建时间',
            align: 'center',
            sortable: true,
        },{
            field: 'testcases_updator',
            title: '更新者',
            align: 'center',
            sortable: true,
        },{
            field: 'testcases_updatetime',
            title: '更新时间',
            align: 'center',
            sortable: true,
        }
        ],
    });
}

initTable($("#module_name").val());

function StatusFormatter(value,row,index) {
    if (value == 0){
        return "<span class='label label-success'>正常</span>"
    }else if(value ==1){
        return "<span class='label label-default'>错误</span>"
    }else if(value ==2){
        return "<span class='label label-danger'>弃用</span>"
    }
}

function AddModuleCase() {
    if ($("#modify").val() == 0) {
        swal('权限不足', '', 'error');
    } else {
        $("#myModal").modal('show');
        var box = $("#ModalFoot");
        box.find(".btn-primary").unbind('click');
        box.find(".btn-primary").on("click", function () {
            var formData = new FormData();
            var test_id = $("#test_id").val();
            var topic = $("#topic").val();
            var type = $("#type").val();
            var steps = $("#steps").val();
            var expected = $("#expected").val();
            var status = $("#status").val();
            var module_name = $("#module_name").val();
            formData.append('test_id', test_id);
            formData.append('topic', topic);
            formData.append('type', type);
            formData.append('steps', steps);
            formData.append('expected', expected);
            formData.append('status', status);
            formData.append('module_name', module_name);
            $.ajax({
                type: 'POST',
                data: formData,
                processData: false,
                // 告诉jQuery不要去设置Content-Type请求头
                contentType: false,
                url: '/AjaxAddM',
                beforeSend: function () {
                    if (test_id == '') {
                        swal('请输入用例号', '', 'error');
                        return false;
                    } else if (topic == '') {
                        swal('请输入用例主题', '', 'error');
                        return false;
                    } else if (steps == '') {
                        swal('请输入步骤', '', 'error');
                        return false;
                    } else if (expected == '') {
                        swal('请输入期待结果', '', 'error');
                        return false;
                    }
                },
                success: function (data) {
                    if (data == '新建成功') {
                        swal({
                                title: data,
                                type: "success",
                                showCancelButton: false,
                                confirmButtonColor: "#DD6B55",
                                confirmButtonText: "确定",
                                closeOnConfirm: true
                            },
                            function () {
                                $("#myModal").modal('hide');
                                $('#ModuleCaseList').bootstrapTable('refresh');
                            });
                    } else {
                        swal(data, '', 'error');
                    }
                }
            })
        })
    }
}


function EditModuleCase() {
    if ($("#modify").val() == 0) {
        swal('权限不足', '', 'error');
    } else {
        var selects = $('#ModuleCaseList').bootstrapTable('getSelections');
        if (selects.length != 1) {
            swal('请选择一个用例编辑', '', 'error');
        } else {
            var id = selects[0].id;
            $.ajax({
                type: 'GET',
                data: {
                    'id': id
                },
                url: '/AjaxEditM',
                success: function (data) {
                    $("#test_id").val(data.test_id);
                    $("#topic").val(data.topic);
                    $("#type").val(data.type);
                    $("#steps").val(data.steps);
                    $("#expected").val(data.expected);
                    $("#status").val(data.status);
                    $("#test_id").attr("disabled", true);
                },
                complete: function () {
                    $("#myModal").modal('show');
                    var box = $("#ModalFoot");
                    box.find(".btn-primary").unbind('click');
                    box.find(".btn-primary").on("click", function () {
                        $.ajax({
                            type: 'GET',
                            data: {
                                'test_id': $("#test_id").val(),
                                'topic': $("#topic").val(),
                                'type': $("#type").val(),
                                'steps': $("#steps").val(),
                                'expected': $("#expected").val(),
                                'status': $("#status").val(),
                            },
                            url: '/AjaxUpdateM',
                            beforeSend: function () {
                                if ($("#test_id").val() == '') {
                                    swal('请输入用例号', '', 'error');
                                    return false;
                                } else if ($("#topic").val() == '') {
                                    swal('请输入用例主题', '', 'error');
                                    return false;
                                } else if ($("#steps").val() == '') {
                                    swal('请输入步骤', '', 'error');
                                    return false;
                                } else if ($("#expected").val() == '') {
                                    swal('请输入期待结果', '', 'error');
                                    return false;
                                }
                            },
                            success: function (data) {
                                swal({
                                        title: data,
                                        text: "",
                                        type: "success",
                                        showCancelButton: false,
                                        confirmButtonColor: "#DD6B55",
                                        confirmButtonText: "确定",
                                        closeOnConfirm: true
                                    },
                                    function () {
                                        $("#myModal").modal('hide');
                                        $("#ModuleCaseList").bootstrapTable('refresh');
                                        $("#test_id").attr("disabled", false);
                                        $("#ModuleCaseForm")[0].reset();
                                    });
                            }
                        })
                    });
                    box.find(".btn-default").unbind('click');
                    box.find(".btn-default").on("click", function () {
                        $("#test_id").attr("disabled", false);
                        $("#ModuleCaseForm")[0].reset();
                        $("#myModal").modal('hide');
                    })
                }
            })
        }
    }
}

function DeleteModuleCase() {
    if ($("#modify").val() == 0) {
        swal('权限不足', '', 'error');
    } else {
        var selects = $('#ModuleCaseList').bootstrapTable('getSelections');
        if (selects.length == 0) {
            swal('请至少选择一个用例', '', 'error');
        } else {
            var SelectsTestIdList = new Array();
            for (i in selects) {
                SelectsTestIdList.push(selects[i].test_id);
            }
            swal({
                    title: "确定删除指定的用例吗?",
                    text: "您将无法恢复指定的用例!",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    cancelButtonText: "取消",
                    confirmButtonText: "确定",
                    closeOnConfirm: false
                },
                function () {
                    $.ajax({
                        type: 'GET',
                        data: {'SelectsTestIdList': JSON.stringify(SelectsTestIdList)},
                        dataType: "json",
                        url: '/AjaxDeleteM',
                        success: function (data) {
                            swal({
                                    title: data,
                                    text: "",
                                    type: "success",
                                    showCancelButton: false,
                                    confirmButtonColor: "#DD6B55",
                                    confirmButtonText: "确定",
                                    closeOnConfirm: true
                                },
                                function () {
                                    $("#ModuleCaseList").bootstrapTable('refresh');
                                });

                        }
                    })
                });
        }
    }
}
