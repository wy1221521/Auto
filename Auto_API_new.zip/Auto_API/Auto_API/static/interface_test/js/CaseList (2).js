function initTable() {
    $('#SuiteList').bootstrapTable({
        url: '/SuiteList' ,              //请求后台的URL（*）
        method: 'get',                      //请求方式（*）
        toolbar: '#toolbar',                //工具按钮用哪个容器
        striped: true,                      //是否显示行间隔色
        cache: false,                       //是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
        pagination: true,                   //是否显示分页（*）
        sidePagination: "client",           //分页方式：client客户端分页，server服务端分页（*）
        pageNumber: 1,                       //初始化加载第一页，默认第一页
        pageSize: 10,                       //每页的记录行数（*）
        pageList: [10, 20],        //可供选择的每页的行数（*）
        search: true,                       //是否显示表格搜索
        strictSearch: false,                //false 模糊搜索
        showColumns: false,                  //是否显示所有的列
        showRefresh: true,                  //是否显示刷新按钮
        singleSelect: true,
        height: 800,                        //行高，如果没有设置height属性，表格自动根据记录条数觉得表格高度
        uniqueId: "uid",                     //每一行的唯一标识，一般为主键列
        showToggle: true,                    //是否显示详细视图和列表视图的切换按钮
        cardView: false,                    //是否显示详细视图
        detailView: false,                   //是否显示父子表
        clickToSelect: true,
        maintainSelected: false,
        columns: [{
                field:'ck',
                checkbox:true,
            },{
            field: 'suite_id',
            title: '编号',
            align: 'center',
            sortable: true,
        }, {
            field: 'suite_name',
            title: '套件名称',
            align: 'center',
            sortable: true,
        }, {
            field: 'suite_status',
            title: '套件状态',
            align: 'center',
            sortable: true,
            formatter:ValueFormatter,
        }, {
            field: 'suite_creator',
            title: '套件创建者',
            align: 'center',
            sortable: true,
        }, {
            field: 'suite_createtime',
            title: '套件创建时间',
            align: 'center',
            sortable: true,
        },{
            field: 'suite_comments',
            title: '套件描述',
            align: 'center',
            sortable: true,
        },
            {
            field: 'operation',
            title: '操作',
            align: 'center',
            sortable: true,
            formatter:OperateFormatter,
        },
        ],
        onDblClickRow:function(row, $element){
            location.href ='/GetCaseList?suite_id='+row.suite_id;
            // window.open ='10.43.101.155:8000/SuiteList';
            // var url = '10.43.101.155:8000/SuiteList'
            // window.open(url););
        }
    });
}

initTable();


function ValueFormatter(value) {
    if (value == 0){
        return "<span class='label label-success'>通过</span>"
    }else if(value ==1){
        return "<span class='label label-default'>失败</span>"
    }else if(value ==2){
        return "<span class='label label-danger'>错误</span>"
    }else if(value ==3){
        return "<span class='label label-info'>新建</span>"
    }
}

function OperateFormatter(value,row,index){
    return "<button class=\"btn btn-default btn-rounded btn-sm\" onClick=\"echo_report("+row.suite_id+")\"><span class=\"fa fa-search\"></span></button>"+
        "<button class=\"btn btn-default btn-rounded btn-sm\" onClick=\"echo_data()\"><span class=\"fa fa-search\"></span></button>"
}



function echo_report() {
     $.ajax({
         url: "/index",
         type: 'get',
     })
}

function echo_data() {
           $.ajax({
type:"get",
url:"http://127.0.0.1:8000",
// url:"http://10.43.101.155:8000/SuiteList",
dataType:"jsonp",
jsonpCallback:"cb",
success:function(){
}
});
}

function Upload(){
   if($("#edit").val()==0){
        swal('权限不足','','error');
   }else {
       $("#UploadModal").modal('show');
       var box = $("#ModalFoot");
       box.find(".btn-primary").unbind('click');
       box.find(".btn-primary").on("click", function () {
           var form_data = new FormData();
           var file_info = $('#file_upload')[0].files[0];
           form_data.append('file',file_info);
           form_data.append('sid',"110");
           $.ajax({
                       url:"/Upload",
                       type:'POST',
                       data: form_data,
                       beforeSend: function () {
                               if ($("#file_upload").val() == '') {
                                   swal('请添加文件', '', 'error');
                                   return false;
                               }
                           },
                       processData: false,  // tell jquery not to process the data
                       contentType: false, // tell jquery not to set contentType
                       success: function(file_exist) {
                            if(file_exist ==1){
                                swal('上传失败,文件重复','','error');
                                 return false;
                             }else if(file_exist ==0){
                                swal('上传成功','','success');
                                $("#UploadModal").modal('hide');
                                $("#SuiteList").bootstrapTable('refresh');
                                 return false;
                             }else if(file_exist ==3){
                                swal('该套件已存在','','error');
                                 return false;
                             }
                           $("#UploadModal").modal('hide');
                           $("#SuiteList").bootstrapTable('refresh');
                       }
                    });
       });
       box.find(".btn-default").unbind('click');
       box.find(".btn-default").on("click", function () {
           $("#SuiteForm")[0].reset();
           $("#UploadModal").modal('hide');
       })



}}

function DeleteSuite(){
    if($("#modify").val()==0){
        swal('权限不足','','error');
   }else {
        var selects = $('#SuiteList').bootstrapTable('getSelections');
        if (selects.length == 0) {
            swal('请选择一个套件', '', 'error');
        } else {
            swal({
                    title: "确定删除此套件?",
                    type: "warning",
                    showCancelButton: true,
                    cancelButtonText: "取消",
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "确定",
                    closeOnConfirm: false
                },
                function () {
                    $.ajax({
                        type: 'GET',
                        data: {
                            'suite_id': selects[0].suite_id
                        },
                        url: '/AjaxDeleteSuite',
                        success: function (data) {
                            if (data == '删除成功') {
                                swal({
                                        title: data,
                                        type: "success",
                                        showCancelButton: false,
                                        confirmButtonColor: "#DD6B55",
                                        confirmButtonText: "确定",
                                        closeOnConfirm: true
                                    },
                                    function () {
                                        $('#SuiteList').bootstrapTable('refresh');
                                    })
                            } else {
                                swal(data, '', 'warning');
                            }
                        }
                    })
                })
        }
    }
}

function EditSuite(){
    if($("#modify").val()==0){
        swal('权限不足','','error');
   }else {
        var selects = $('#SuiteList').bootstrapTable('getSelections');
        if (selects.length == 0) {
            swal('请选择一个套件', '', 'error');
        } else {
            $.ajax({
                type: 'GET',
                data: {
                    'suite_id': selects[0].suite_id
                },
                url: '/AjaxEditSuite',
                success: function (data) {
                    $("#SuiteName").val(data.suite_name);
                    $("#SuiteStatus").val(data.suite_status);
                    $("#SuiteDescription").val(data.suite_comments);
                },
                complete: function () {
                    $("#EditModal").modal('show');
                    var box = $("#EditModalFoot");
                    box.find(".btn-primary").unbind('click');
                    box.find(".btn-primary").on("click", function () {
                        var form_data = new FormData();
                        var file_info = $('#file_upload')[0].files[0];
                        form_data.append('file',file_info);
                        $.ajax({
                            type: 'GET',
                            data: {
                                'suite_id': selects[0].suite_id,
                                'suite_name': $("#SuiteName").val(),
                                'suite_status': $("#SuiteStatus").val(),
                                'suite_comments': $("#SuiteDescription").val()

                            },
                            url: '/AjaxUpdateSuite',
                            beforeSend: function () {
                                if ($("#SuiteName").val() == '') {
                                    swal('请输入项目名称', '', 'error');
                                    return false;
                                } else if ($("#SuiteStatus").val() == '') {
                                    swal('请输入项目状态', '', 'error');
                                    return false;
                                } else if ($("#SuiteDescription").val() == '') {
                                    swal('请输入项目描述', '', 'error');
                                    return false;
                                }
                            },
                            success: function (data) {
                                swal({
                                        title: data,
                                        text: "",
                                        type: "success",
                                        showCancelButton: false,
                                        confirmButtonColor: "#DD6B55",
                                        confirmButtonText: "确定",
                                        closeOnConfirm: true
                                    },
                                    function () {
                                        $("#EditModal").modal('hide');
                                        $("#SuiteList").bootstrapTable('refresh');
                                    });
                            }
                        })

                    });
                    box.find(".btn-default").unbind('click');
                    box.find(".btn-default").on("click", function () {
                        $("#SuiteForm")[0].reset();
                        $("#myModal").modal('hide');
                    })
                }
            })
        }
    }
}

function Execute(data) {
    var selects = $('#SuiteList').bootstrapTable('getSelections');
    if (selects.length == 0) {
        swal('请至少选择一个套件', '', 'error');
    } else {
        var ii = layer.load();
        var SelectsCaseIdList = new Array();
        for (i in selects) {
            SelectsCaseIdList.push(selects[i].suite_id);
        }
        $.ajax({
            type: 'GET',
            data: {
                'type':'suite',
                'SelectsCaseIdList': JSON.stringify(SelectsCaseIdList)
            },
            url: '/ExecuteCase',
            success: function (ddd) {
                layer.close(ii);
                $("#SuiteList").bootstrapTable('refresh');
                window.open("/OpenHtml?file="+ddd, "_blank");
            }
        })
    }
}