$(document).ready(function(){
  $('input').iCheck({
    checkboxClass: 'icheckbox_square-blue',
    radioClass: 'iradio_square-blue',
    increaseArea: '20%' // optional
  });
  $('#timer').on('ifChecked', function(event){
        $("#TimerRule").attr("disabled",false);
    });


  $('#timer').on('ifUnchecked', function(event){
   $("#TimerRule").attr("disabled",true);
    });

  $("#TimerRule").attr("disabled",true);
});


function AddTask(){
   location.href = '/AddTask'
}

$("#SelectProject").select2({
      placeholder:'请选择',
      ajax: {
        url: "/SelectProject",
        dataType: 'json',
        delay: 250,
        data: function (params) {
          return {
            search: params.term,
          };
        },
        processResults: function (data) {
          return {
            results: data
          };
        },
        cache: true
      },
    }
);

$("#SelectProject").on('select2:select',function(e){
    var data = e.params.data;
    $.ajax({
        type:'GET',
        data:{
            'project_id':data.id,
        },
        url:'/ModelCheck',
        success:function(data){
          $('#ModelDiv').empty();
          for(i in data){
             if(i % 5 == 4){
                 $('#ModelDiv').append("<input type='checkbox' value='"+data[i].module_id+"'><label>"+data[i].module_name+"&nbsp;"+"&nbsp;"+"&nbsp;"+"&nbsp;"+"</label></br></br> ")
             }  else{
                 $('#ModelDiv').append("<input type='checkbox' value='"+data[i].module_id+"'><label>"+data[i].module_name+"&nbsp;"+"&nbsp;"+"&nbsp;"+"&nbsp;"+"</label> ")
             }

          }

          $('input').iCheck({
            checkboxClass: 'icheckbox_square-blue',
            radioClass: 'iradio_square-blue',
            increaseArea: '20%' // optional
          });
            $('#timer').on('ifChecked', function(event){
                $("#TimerRule").attr("disabled",false);
            });


              $('#timer').on('ifUnchecked', function(event){
               $("#TimerRule").attr("disabled",true);
                });

        }
    })
}
);

function Submit(){
   var TaskName = $('#TaskName').val();
   var ProjectId = $('#SelectProject').val();
   var timer = $("input[id='timer']").is(':checked');
   var timer_rule = $('#TimerRule').val();
   var comments =  $('#comments').val();

   var SelectModelList = new Array();
   var SelectModel = $("#ModelDiv div.checked").children(":checkbox");//获取id为ModelDiv下的 div class为checked的子元素,子元素中的checkbox
   SelectModel.each(function(){               //each 遍历jquery元素
        SelectModelList.push($(this).val());
   });
   var ModelList = JSON.stringify(SelectModelList);
   $.ajax({
       type:'GET',
       data:{
           'TaskName':TaskName,
           'ProjectId':ProjectId,
           'ModelList':ModelList,
           'timer':timer,
           'timer_rule':timer_rule,
           'comments':comments,
       },
       url:'/SubmitTask',
       beforeSend:function () {
                   if(TaskName ==''){
                    swal('请输入任务名称','','error');
                    return false;
                   }else if(comments == ''){
                    swal('请输入任务描述','','error');
                    return false;
                   }else if(ProjectId == null){
                    swal('请选择项目','','error');
                    return false;
                   }else if(SelectModelList.length == 0){
                     swal('请选择模块','','error');
                     return false;
                   }else if(cronValidate(timer_rule) == false){
                     if(timer == true){
                       swal('请输入正确的定时规则','','error');
                       return false;
                     }
                   }
               },
       success:function(data){
           swal({
                  title: data,
                  type: "success",
                  showCancelButton: true,
                  confirmButtonColor: "#DD6B55",
                  confirmButtonText: "返回上一页",
                  cancelButtonText: "留在当前页",
                  closeOnConfirm: false,
                  closeOnCancel: true,
                },
                function(isConfirm){
                  if (isConfirm) {
                    location.href = '/TaskList';
                  }
                });

       }
   })
}

// function Cancel(){
//     $("#TimerRule").css({"border":"1px solid white"});
//     $("#TimerRule").css({"border":""});
// }





