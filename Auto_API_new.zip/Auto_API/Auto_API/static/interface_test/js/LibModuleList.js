function initTable() {
    $('#LibModuleList').bootstrapTable({
        url: '/LibModuleIndex' ,           //请求后台的URL（*）
        method: 'get',                      //请求方式（*）
        toolbar: '#toolbar',                //工具按钮用哪个容器
        striped: true,                      //是否显示行间隔色
        cache: false,                       //是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
        pagination: true,                   //是否显示分页（*）
        sidePagination: "client",           //分页方式：client客户端分页，server服务端分页（*）
        pageNumber: 1,                      //初始化加载第一页，默认第一页
        pageSize: 10,                       //每页的记录行数（*）
        pageList: [10, 20, 50, 100],        //可供选择的每页的行数（*）
        search: true,                       //是否显示表格搜索
        strictSearch: false,                //false 模糊搜索
        showColumns: false,                 //是否显示所有的列
        showRefresh: true,                  //是否显示刷新按钮
        singleSelect: true,
        height: 800,                        //行高，如果没有设置height属性，表格自动根据记录条数决定表格高度
        uniqueId: "uid",                    //每一行的唯一标识，一般为主键列
        showToggle: true,                   //是否显示详细视图和列表视图的切换按钮
        cardView: false,                    //是否显示详细视图
        detailView: false,                  //是否显示父子表
        clickToSelect: true,
        maintainSelected: false,
        columns: [ {
                field:'ck',
                checkbox:true,
            },{
            field: 'module_id',
            title: '模块号',
            align: 'center',
            sortable: true,
        },  {
            field: 'module_name',
            title: '模块名称',
            align: 'center',
            sortable: true,
        }, {
            field: 'module_creator',
            title: '模块创建者',
            align: 'center',
            sortable: true,
        },{
            field: 'module_createtime',
            title: '模块创建时间',
            align: 'center',
            sortable: true,
        },{
            field: 'module_updator',
            title: '模块更新者',
            align: 'center',
            sortable: true,
        },{
            field: 'module_updatetime',
            title: '模块更新时间',
            align: 'center',
            sortable: true,
        },{
            field: 'comments',
            title: '描述',
            align: 'center',
            sortable: true,
        },
        ],
        onDblClickRow:function(row, $element){
            location.href ='/LibModuleCase?module_id='+row.module_id+'&module_name='+row.module_name;
        }
    });
}

initTable();

function AddLibModule() {
    if ($("#modify").val() == 0) {
        swal('权限不足', '', 'error');
    } else {
        $("#myModal").modal('show');
        var box = $("#ModalFoot");
        box.find(".btn-primary").unbind('click');
        box.find(".btn-primary").on("click", function () {
            var ModuleName = $("#ModuleName").val();
            var ModuleDescription = $("#ModuleDescription").val();
            $.ajax({
                type: 'GET',
                data: {
                    'ModuleName': ModuleName,
                    'ModuleDescription': ModuleDescription,
                },
                url: '/AjaxAddLibModule',
                beforeSend: function () {
                    if (ModuleName == '') {
                        swal('请输入模块名称', '', 'error');
                        return false;
                    }
                },
                success: function (data) {
                    swal({
                            title: data,
                            type: "success",
                            showCancelButton: false,
                            confirmButtonColor: "#DD6B55",
                            confirmButtonText: "确定",
                            closeOnConfirm: true
                        },
                        function () {
                            $("#myModal").modal('hide');
                            $('#LibModuleList').bootstrapTable('refresh');
                        });
                },
            })
        })
    }
}

function EditLibModule() {
    if ($("#modify").val() == 0) {
        swal('权限不足', '', 'error');
    } else {
        var selects = $('#LibModuleList').bootstrapTable('getSelections');
        if (selects.length != 1) {
            swal('请选择一个用例进行修改', '', 'error');
        } else {
            $.ajax({
                type: 'GET',
                data: {
                    'module_id': selects[0].module_id
                },
                url: '/AjaxEditLibModule',
                success: function (data) {
                    $("#ModuleName").val(data.module_name);
                    $("#ModuleDescription").val(data.comments);
                },
                complete: function () {
                    $("#myModal").modal('show');
                    var box = $("#ModalFoot");
                    box.find(".btn-primary").unbind('click');
                    box.find(".btn-primary").on("click", function () {
                        $.ajax({
                            type: 'GET',
                            data: {
                                'module_id': selects[0].module_id,
                                'module_name': $("#ModuleName").val(),
                                'comments': $("#ModuleDescription").val()
                            },
                            url: '/AjaxUpdateLibModule',
                            beforeSend: function () {
                                if ($("#ModuleName").val() == '') {
                                    swal('请输入模块名称', '', 'error');
                                    return false;
                                }
                            },
                            success: function (data) {
                                swal({
                                        title: data,
                                        text: "",
                                        type: "success",
                                        showCancelButton: false,
                                        confirmButtonColor: "#DD6B55",
                                        confirmButtonText: "确定",
                                        closeOnConfirm: true
                                    },
                                    function () {
                                        $("#myModal").modal('hide');
                                        $("#LibModuleList").bootstrapTable('refresh');
                                    });
                            }
                        })
                    });
                    box.find(".btn-default").unbind('click');
                    box.find(".btn-default").on("click", function () {
                        $("#LibModuleForm")[0].reset();
                        $("#myModal").modal('hide');
                    })
                }
            })
        }
    }
}

function DeleteLibModule() {
    if ($("#modify").val() == 0) {
        swal('权限不足', '', 'error');
    } else {
        var selects = $('#LibModuleList').bootstrapTable('getSelections');
        if (selects.length == 0) {
            swal('请选择一个用例', '', 'error');
        } else {
            swal({
                    title: "确定删除指定的模块吗?",
                    text: "您将无法恢复指定的模块!",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    cancelButtonText: "取消",
                    confirmButtonText: "确定",
                    closeOnConfirm: false
                },
                function () {
                    $.ajax({
                        type: 'GET',
                        data: {'SelectsLibModuleId': selects[0].module_id},
                        url: '/AjaxDeleteLibModule',
                        success: function (data) {
                            swal({
                                    title: data,
                                    text: "",
                                    type: "success",
                                    showCancelButton: false,
                                    confirmButtonColor: "#DD6B55",
                                    confirmButtonText: "确定",
                                    closeOnConfirm: true
                                },
                                function () {
                                    $("#LibModuleList").bootstrapTable('refresh');
                                });

                        }
                    })
                });
        }
    }
}