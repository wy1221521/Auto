define({
  "name": "",
  "version": "0.0.0",
  "description": "",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-06-25T07:07:57.908Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
