define({ "api": [
  {
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "optional": false,
            "field": "varname1",
            "description": "<p>No type.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "varname2",
            "description": "<p>With type.</p>"
          }
        ]
      }
    },
    "type": "",
    "url": "",
    "version": "0.0.0",
    "filename": "./doc/doc/main.js",
    "group": "D__works_Auto_API_doc_doc_main_js",
    "groupTitle": "D__works_Auto_API_doc_doc_main_js",
    "name": ""
  },
  {
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "optional": false,
            "field": "varname1",
            "description": "<p>No type.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "varname2",
            "description": "<p>With type.</p>"
          }
        ]
      }
    },
    "type": "",
    "url": "",
    "version": "0.0.0",
    "filename": "./doc/main.js",
    "group": "D__works_Auto_API_doc_main_js",
    "groupTitle": "D__works_Auto_API_doc_main_js",
    "name": ""
  },
  {
    "type": "POST",
    "url": "/Execute/?id=XXX/",
    "title": "执行用例",
    "version": "1.0.0",
    "description": "<p>执行用例</p>",
    "name": "Execute",
    "group": "InterfaceTest",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "id",
            "description": "<p>套件ID或者用例ID</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "type",
            "description": "<p>类型：suite or case</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "请求成功(case)",
          "content": "HTTP/1.1 200 OK\n{\n     \"case\": {\n         \"id\": \"24\",\n         \"code\": 0,\n         \"error\": false,\n         \"msg\": \"success\"\n     }\n }",
          "type": "json"
        },
        {
          "title": "请求成功(suite)",
          "content": "HTTP/1.1 200 OK\n{\n     \"suite\": {\n         \"id\": \"4\",\n         \"code\": 0,\n         \"error\": false,\n         \"msg\": \"success\"\n     }\n }",
          "type": "json"
        }
      ],
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "id",
            "description": "<p>id值</p>"
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "code",
            "description": "<p>0</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "error",
            "description": "<p>false</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "message",
            "description": "<p>返回消息</p>"
          }
        ]
      }
    },
    "filename": "./Auto_API/interface_test/views.py",
    "groupTitle": "InterfaceTest"
  },
  {
    "type": "GET",
    "url": "/GetCaseList?suite_id=XXX/",
    "title": "获取套件下用例列表",
    "version": "1.0.0",
    "description": "<p>获取套件下用例列表</p>",
    "name": "GetCaseList",
    "group": "InterfaceTest",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "suite_id",
            "description": "<p>套件ID</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "请求成功",
          "content": "HTTP/1.1 200 OK\n  {\n      \"data\": [\n          {\n              \"id\": 21,\n              \"case_id\": \"TC_INT_001\",\n              \"case_name\": \" 获取登录页\",\n              \"case_description\": null,\n              \"case_method\": \"\",\n              \"case_service_id\": null,\n              \"case_project_id\": null,\n              \"case_creator\": null,\n              \"case_comments\": null,\n              \"case_createtime\": null,\n              \"case_status\": \"FAIL\"\n          },\n          {\n              \"id\": 22,\n              \"case_id\": \"TC_INT_002\",\n              \"case_name\": \" createsession\",\n              \"case_description\": null,\n              \"case_method\": \"\",\n              \"case_service_id\": null,\n              \"case_project_id\": null,\n              \"case_creator\": null,\n              \"case_comments\": null,\n              \"case_createtime\": null,\n              \"case_status\": \"PASS\"\n          },\n\n      ],\n      \"code\": 0,\n      \"error\": false,\n      \"msg\": \"success\"\n  }",
          "type": "json"
        }
      ],
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Array",
            "optional": false,
            "field": "data",
            "description": "<p>数据列表</p>"
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "code",
            "description": "<p>0</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "error",
            "description": "<p>false</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "message",
            "description": "<p>返回消息</p>"
          }
        ]
      }
    },
    "filename": "./Auto_API/interface_test/views.py",
    "groupTitle": "InterfaceTest"
  },
  {
    "type": "GET",
    "url": "/GetResult/?id=XXX&type=XXX/",
    "title": "获取运行结果",
    "version": "1.0.0",
    "description": "<p>获取运行结果</p>",
    "name": "GetResult",
    "group": "InterfaceTest",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "id",
            "description": "<p>套件ID或者用例ID</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "type",
            "description": "<p>类型：suite or case</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "请求成功(case)",
          "content": "HTTP/1.1 200 OK\n{\n      \"case\": {\n          \"case_name\": \" Test weather\",\n          \"status\": \"PASS\",\n          \"logs\": \"\",\n          \"start_time\": \"20180622 16:43:26.240\",\n          \"end_time\": \"20180622 16:43:26.466\"\n      },\n      \"code\": 0,\n      \"error\": false,\n      \"msg\": \"success\"\n }",
          "type": "json"
        },
        {
          "title": "请求成功(suite)",
          "content": "HTTP/1.1 200 OK\n{\n      \"suite\": {\n          \"status\": \"FAIL\",\n          \"passed\": 3,\n          \"failed\": 2,\n          \"count\": 5,\n          \"rate\": \"0.6%\",\n          \"start_time\": \"20180531 14:01:24.178\",\n          \"end_time\": \"20180531 14:01:25.138\"\n      },\n      \"cases\": [\n                  {\n                      \"case_name\": \" 获取登录页\",\n                      \"logs\": \"Keyword '回应' expected 0 arguments, got 3.\"\n                  },\n                  {\n                      \"case_name\": \" createsession\",\n                      \"logs\": \"20180531 14:01:24.597\"\n                  },\n                  {\n                      \"case_name\": \" get\",\n                      \"logs\": \"20180531 14:01:24.866\"\n                  },\n                  {\n                      \"case_name\": \" post\",\n                      \"logs\": \"20180531 14:01:25.136\"\n                  },\n                  {\n                      \"case_name\": \"登录\",\n                      \"logs\": \"Keyword '登录' expected 5 arguments, got 2.\"\n                  }\n               ],\n      \"code\": 0,\n      \"error\": false,\n      \"msg\": \"success\"\n }",
          "type": "json"
        }
      ],
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "id",
            "description": "<p>id值</p>"
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "code",
            "description": "<p>0</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "error",
            "description": "<p>false</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "message",
            "description": "<p>返回消息</p>"
          }
        ]
      }
    },
    "filename": "./Auto_API/interface_test/views.py",
    "groupTitle": "InterfaceTest"
  },
  {
    "type": "GET",
    "url": "/SuiteMsg?suite_id=XXX/",
    "title": "获取套件信息",
    "version": "1.0.0",
    "description": "<p>获取套件信息</p>",
    "name": "GetSuiteMsg",
    "group": "InterfaceTest",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "suite_id",
            "description": "<p>套件ID</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "请求成功",
          "content": "HTTP/1.1 200 OK\n{\n    \"suite_name\": \"\\u65e5\\u671f\",\n    \"suite_status\": \"3\",\n    \"suite_comments\": \"eqwewqe\",\n    \"code\": 0,\n    \"error\": false,\n    \"msg\": u'success'\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "suite_name",
            "description": "<p>套件名</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "suite_status",
            "description": "<p>套件状态</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "suite_comments",
            "description": "<p>套件说明</p>"
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "code",
            "description": "<p>0</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "error",
            "description": "<p>false</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "message",
            "description": "<p>返回消息</p>"
          }
        ]
      }
    },
    "filename": "./Auto_API/interface_test/views.py",
    "groupTitle": "InterfaceTest"
  },
  {
    "type": "GET",
    "url": "/SuiteList?service_id=XXX/",
    "title": "获取套件列表",
    "version": "1.0.0",
    "description": "<p>获取套件列表, 若service_id 未指定则获取全部套件</p>",
    "name": "GetSuiteView",
    "group": "InterfaceTest",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "service_id",
            "description": "<p>套件ID</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "请求成功",
          "content": "HTTP/1.1 200 OK\n{\n    \"data\": [{\"suite_id\": \"TS_INT_3\", \"suite_name\": \"\\u65e5\\u671f\", \"suite_creator\": \"me\", \"suite_createtime\": \"20180516\", \"suite_comments\": \"eqwewqe\", \"suite_status\": \"3\"}, {\"suite_id\": \"TS_INT_4\", \"suite_name\": \"\\u5929\\u6c14\", \"suite_creator\": \"\", \"suite_createtime\": \"2018/05/29 17:43:14\", \"suite_comments\": \"\", \"suite_status\": \"1\"}],\n    \"code\": 0,\n    \"error\": false,\n    \"msg\": u'success'\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Array",
            "optional": false,
            "field": "data",
            "description": "<p>数据列表</p>"
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "code",
            "description": "<p>0:成功；1：失败</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "error",
            "description": "<p>false</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "message",
            "description": "<p>返回消息</p>"
          }
        ]
      }
    },
    "filename": "./Auto_API/interface_test/views.py",
    "groupTitle": "InterfaceTest"
  },
  {
    "type": "DELETE",
    "url": "/SuiteDelete?suite_id=XXX/",
    "title": "删除指定套件",
    "version": "1.0.0",
    "description": "<p>删除指定套件</p>",
    "name": "SuiteDelete",
    "group": "InterfaceTest",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "suite_id",
            "description": "<p>套件ID</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "请求成功",
          "content": "HTTP/1.1 200 OK\n{\n    \"code\": 0,\n    \"error\": false,\n    \"msg\": u'success'\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "code",
            "description": "<p>0</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "error",
            "description": "<p>false</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "message",
            "description": "<p>返回消息</p>"
          }
        ]
      }
    },
    "filename": "./Auto_API/interface_test/views.py",
    "groupTitle": "InterfaceTest"
  },
  {
    "type": "POST",
    "url": "/SuiteUpdate/",
    "title": "更新套件信息",
    "version": "1.0.0",
    "description": "<p>更新套件信息</p>",
    "name": "SuiteUpdate",
    "group": "InterfaceTest",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "suite_id",
            "description": "<p>套件ID</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "status",
            "description": "<p>套件状态</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "comment",
            "description": "<p>套件说明</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "请求成功",
          "content": "HTTP/1.1 200 OK\n{\n     \"id\": \"4\",\n     \"code\": 1,\n     \"error\": false\n     \"msg\": \" success\"\n }",
          "type": "json"
        }
      ],
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "suite_name",
            "description": "<p>套件ID</p>"
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "code",
            "description": "<p>0</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "error",
            "description": "<p>false</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "message",
            "description": "<p>返回消息</p>"
          }
        ]
      }
    },
    "filename": "./Auto_API/interface_test/views.py",
    "groupTitle": "InterfaceTest"
  },
  {
    "type": "POST",
    "url": "/SuiteUpload/",
    "title": "上传套件",
    "version": "1.0.0",
    "description": "<p>上传套件</p>",
    "name": "SuiteUpload",
    "group": "InterfaceTest",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "file",
            "optional": false,
            "field": "file",
            "description": "<p>套件文件</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "service_id",
            "description": "<p>服务ID</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "请求成功",
          "content": "HTTP/1.1 200 OK\n{\n     \"code\": 0,\n     \"error\": false\n     \"msg\": \" success\"\n }",
          "type": "json"
        }
      ],
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "code",
            "description": "<p>0</p>"
          },
          {
            "group": "Success 200",
            "type": "Boolean",
            "optional": false,
            "field": "error",
            "description": "<p>false</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "message",
            "description": "<p>返回消息</p>"
          }
        ]
      }
    },
    "filename": "./Auto_API/interface_test/views.py",
    "groupTitle": "InterfaceTest"
  }
] });
