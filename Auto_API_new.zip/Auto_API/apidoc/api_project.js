define({
  "name": "接口自动化测试平台 API 文档",
  "version": "1.0.0",
  "description": "API 文档-说明",
  "title": "接口自动化测试平台 API 文档-title",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-06-25T08:38:01.589Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
