#!/bin/bash 
#

docker run --name redis -d daocloud.io/redis:3.0.7
