#!/bin/bash 
#

docker stop django
docker rm django
