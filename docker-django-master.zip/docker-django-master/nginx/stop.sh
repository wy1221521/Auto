#!/bin/bash 
#

docker stop nginx-server
docker rm nginx-server
